//CREATE FUNCTION FOR BLACK FRIDAY SALE
function sayFlash() {
console.log("!! BLACK FRIDAY FLASH SALE !! UP TO 20% OFF")
}
sayFlash()

//START BY CONFIRMING AGE BY PROMPT
const age = prompt("How old are you?")

//CREATE 'IF ELSE' COMPARISON OF AGE
if (age >= 18) {
message = "Thank you for confirming that you are over 18. 🤗 We have added new styles to our Black Friday sale, check them out!"
  console.log(message)
} else {
message = "We are very sorry, but we are unable to provide our tattoo services to anyone under the age of 18. However, we can offer you our piercing services. Feel free to contact us for more information."
  
console.log(message)
}
  
 function sayOffer() {
let oldOffer = 200
const discount = 20
console.log("We also are running a promotion on our most popular bundle of 1 tattoo and 1 piercing of your choosing.")
console.log("Old bundle price [£]: " + oldOffer)

oldOffer = oldOffer - ((200 / 100) * discount)
console.log("Sale bundle price [£]: " + oldOffer)
}
  //WRITE PROMPT TO CHOOSE DESIGN STYLE
const design = prompt("What design are you interested in? We currently offer dragon, butterfly and skull designs.")

if (design === "dragon" || design === "Dragon" || design === "DRAGON") {
  message = "All dragon designs are currently 10% off 🐉"
    console.log(message)
  sayOffer()
} 

else if (design === "butterfly" || design === "Butterfly" || design === "BUTTERFLY") {
message = "All butterfly designs are currently 20% off 🦋"
console.log(message)
  sayOffer()
}

else {
  message = "All skull designs are currently 15% off 💀"
  console.log(message)
  sayOffer()
}
              
//REPEAT SALE FUNCTION IN THE END
sayFlash()